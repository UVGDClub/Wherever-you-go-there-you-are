﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HarvChildScript : MonoBehaviour
{

    Vector3 upTeleport;
    Vector3 rightTeleport;

    BoxCollider2D bc2;
    Rigidbody2D parentRB;
    GameObject parent;

    // Start is called before the first frame update
    void Start()
    {
        /*upTeleport = new Vector3(0f, 6.5f, 0f);
        rightTeleport = new Vector3(6.5f, 0f, 0f);
        bc2 = GetComponent<BoxCollider2D>();
        parentRB = transform.parent.GetComponent<Rigidbody2D>();
        parent = transform.parent.gameObject;*/
    }

    // Update is called once per frame
    void FixedUpdate()
    { 

        /*if(transform.position.x < -3.25)
        {
            transform.position += rightTeleport;
        }
        if (transform.position.x > 3.25)
        {
            transform.position -= rightTeleport;
        }
        if (transform.position.y < -3.25)
        {
            transform.position += upTeleport;
        }
        if (transform.position.y > 3.25)
        {
            transform.position -= upTeleport;
        }

        Vector2 velocity = new Vector2(0f, 0f);

        if (Input.GetKey("w"))
        {
            velocity.y += 5f;
        }
        if (Input.GetKey("s"))
        {
            velocity.y -= 5f;
        }
        if (Input.GetKey("a"))
        {
            velocity.x -= 5f;
        }
        if (Input.GetKey("d"))
        {
            velocity.x += 5f;
        }*/



        /*if (velocity.magnitude != 0)
        {
            
            RaycastHit2D hit = Physics2D.Raycast(transform.position, velocity, Mathf.Infinity, LayerMask.GetMask("Default"));

            if (hit.collider != null)
            {
                float xRatio = 1f;
                float yRatio = 1f;

                Vector2 distance = hit.point - As2D(transform.position);
                xRatio = Mathf.Abs(distance.x - (bc2.size.x / 2));
                yRatio = Mathf.Abs(distance.y - (bc2.size.y / 2));

                Debug.Log(hit.point);

                if (xRatio < 5f / 50f)
                {
                    velocity.x *= xRatio;
                }
                if (yRatio < 5f / 50f)
                {
                    velocity.y *= yRatio;
                }

            }
        }*/
        //parentRB.velocity = velocity;
    }

    Vector3 As3D(Vector2 vector)
    {
        return new Vector3(vector.x, vector.y, 0);
    }

    Vector2 As2D(Vector3 vector)
    {
        return new Vector2(vector.x, vector.y);
    }

}


