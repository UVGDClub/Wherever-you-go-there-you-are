﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SteveMoveScript : MonoBehaviour
{

    Vector2 upTeleport;
    Vector2 rightTeleport;

    float speed = 5.0f;
    Rigidbody2D rb;
    public GameObject ChildSprite;
    BoxCollider2D bc2;

    float xScale;
    float yScale;

    public Vector2 bc2loc;

    // Start is called before the first frame update
    void Start()
    {
        upTeleport = new Vector3(0f, 6.5f);
        rightTeleport = new Vector3(6.5f, 0f);
        rb = GetComponent<Rigidbody2D>();
        bc2 = GetComponents<BoxCollider2D>()[1];
        xScale = transform.localScale.x;
        yScale = transform.localScale.y;
    }

    // Update is called once per frame
    void Update()
    {

        bc2loc = new Vector2(transform.position.x + bc2.offset.x*xScale, transform.position.y + bc2.offset.y*yScale);

        if (bc2loc.x < -3.25)
        {
            bc2.offset += rightTeleport/xScale;
            //ChildSprite.transform.position += As3D(rightTeleport);
        }
        if (bc2loc.x > 3.25)
        {
            bc2.offset -= rightTeleport/xScale;
            //ChildSprite.transform.position -= As3D(rightTeleport);
        }
        if (bc2loc.y < -3.25)
        {
            bc2.offset += upTeleport/yScale;
            //ChildSprite.transform.position += As3D(upTeleport);
        }
        if (bc2loc.y > 3.25)
        {
            bc2.offset -= upTeleport/yScale;
            //ChildSprite.transform.position -= As3D(upTeleport);
        }

        ChildSprite.transform.position = As3D(bc2loc);

        Vector2 velocity = new Vector2(0f, 0f);

        if (Input.GetKey("w"))
        {
            velocity.y += 5f;
        }
        if (Input.GetKey("s"))
        {
            velocity.y -= 5f;
        }
        if (Input.GetKey("a"))
        {
            velocity.x -= 5f;
        }
        if (Input.GetKey("d"))
        {
            velocity.x += 5f;
        }


        rb.velocity = velocity;
    }

    Vector3 As3D(Vector2 vector)
    {
        return new Vector3(vector.x, vector.y, 2);
    }

    Vector2 As2D(Vector3 vector)
    {
        return new Vector2(vector.x, vector.y);
    }
}
